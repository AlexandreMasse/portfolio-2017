<?php
    if(isset($_POST['message']) AND !empty($_POST['message']) AND isset($_POST['email']) AND !empty($_POST['email']) AND isset($_POST['Sujet']) AND !empty($_POST['Sujet'])){        
        /* envoi de l'e-mail */
        //envoie mail
        //To
        $to = 'erwann.letue@gmail.com';
        // Subject
        $subject = $_POST['Sujet'];
        // Message
        $msg = $_POST['message'];
        $prov = 'Provenance du mail : '.$_POST['email'];
        // Function mail()
        mail($to, $subject, $msg, $prov);
        echo"Votre message a bien été envoyé !";
    }
    else if(isset($_POST['message'])){
        echo"Votre message n'a pas pu être envoyé. Veuillez compléter correctement tous les champs.";
    }
?>